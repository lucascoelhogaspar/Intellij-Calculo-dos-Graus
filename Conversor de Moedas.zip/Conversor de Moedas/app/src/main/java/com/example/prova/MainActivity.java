package com.example.prova;

import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    EditText texto1;
    EditText texto2;
    RadioButton botaodolar;
    RadioButton botaoeuro;
    RadioButton botaolibra;
    Button converter;
    TextView textoultimo;


    Double valorDolar = 5.0642;
    Double valorEuro = 5.3087;
    Double ValorLibra = 6.1137;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texto1 = findViewById(R.id.texto1);
        texto2 = findViewById(R.id.texto2);
        botaodolar = findViewById(R.id.botaodolar);
        botaoeuro = findViewById(R.id.botaoeuro);
        botaolibra = findViewById(R.id.botaolibra);
        converter = findViewById(R.id.converter);
        textoultimo = findViewById(R.id.textoultimo);

    converter.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String nomeEntrada = texto1.getText().toString();
            Double valorEntrada = Double.parseDouble(texto2.getText().toString());
            Double resultadoFinal = 0.0;
            String moeda = "";

            if (botaodolar.isChecked()){
                resultadoFinal = valorEntrada * valorDolar;
                moeda = "Dolar";

            }else if (botaoeuro.isChecked()){
                resultadoFinal = valorEntrada * valorEuro;
                moeda = "Euro";

            }else if (botaolibra.isChecked()) {
                resultadoFinal = valorEntrada * ValorLibra;
                moeda = "Libra";
            }

            textoultimo.setText("Prezado " + nomeEntrada + "se tiver um salario de " + valorEntrada + " " + moeda + "voce ira receber " + resultadoFinal + "Reais por mes");

        }
    });

    }
}