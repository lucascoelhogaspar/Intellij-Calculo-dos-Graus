package com.example.segundotrabalho;

import android.content.Intent;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity2 extends AppCompatActivity {

    EditText textoentrada;
    Button botao3;
    TextView textoresultadocelsius;
    Button botao4;
    Button botao5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textoentrada = findViewById(R.id.textoentrada);
        botao3 = findViewById(R.id.botao3);
        textoresultadocelsius = findViewById(R.id.textoresultadocelsius);
        botao4 = findViewById(R.id.botao4);
        botao5 = findViewById(R.id.botao5);

        botao3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double valorCelsius = Double.parseDouble(textoentrada.getText().toString());
                Double resultadoFinal = valorCelsius * 1.8 + 32;
                textoresultadocelsius.setText(String.valueOf(resultadoFinal));

            }
        });
        botao4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
        botao5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity3.class);
                startActivity(intent);
            }
        });

    }
}