package com.example.segundotrabalho;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity3 extends AppCompatActivity {

    EditText textoentrada2;
    Button botao6;
    TextView textoresultadofah;
    Button botao7;
    Button botao8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textoentrada2 = findViewById(R.id.textoentrada2);
        botao6 = findViewById(R.id.botao6);
        textoresultadofah = findViewById(R.id.textoresultadofah);
        botao7 = findViewById(R.id.botao7);
        botao8 = findViewById(R.id.botao8);

        botao6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double valorFah = Double.parseDouble(textoentrada2.getText().toString());
                Double valorFinal = (valorFah - 32) / 1.8;
                textoresultadofah.setText(String.valueOf(valorFinal));

            }
        });
        botao7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        botao8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(intent);
            }
        });
    }
}